
        <footer id="footer">
            <div class="container">
                <div class="col-md-3">
                    <h4>About Queenfie Olshop</h4>

                    <p>Online shop <a href="https://www.google.co.id/search?q=queenfieolshop&oq=queenfieolshop&aqs=chrome..69i57j69i60.5569j0j7&sourceid=chrome&ie=UTF-8" target="_blank">terpercaya</a> yang base di instagram <a target="_blank" href="http://instagram.com/queenfieolshop">@queenfieolshop</a></p>

                    <hr>

                    

                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->

                <div class="col-md-3">

                                    <h3>Follow instagram kami untuk tau info terupdate dan dapatkan diskon-diskonnya.</h3>

                    <hr>

                    

                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->

                <div class="col-md-3">

                    <h4>Contact</h4>

                    <p><strong>Owner: Fixalis Oktafia.</strong>
                        <br>Surabaya
                        <strong>Indonesia</strong>
                    </p>

                    <a href="http://instagram.com/queenfieolshop" target=""class="btn btn-small btn-template-main">Go follow our instagram</a>

                    <hr class="hidden-md hidden-lg hidden-sm">

                </div>
                <!-- /.col-md-3 -->



               
                <!-- /.col-md-3 -->
            </div>
            <!-- /.container -->
        </footer>
        <!-- /#footer -->

        <!-- *** FOOTER END *** -->

        <!-- *** COPYRIGHT ***
_________________________________________________________ -->

        <div id="copyright">
            <div class="container">
                <div class="col-md-12">
                    <p class="pull-left">&copy; 2017. Queenfie Olshop</p>
                    <p class="pull-right">Template by <a href="https://bootstrapious.com">Bootstrapious</a> & <a href="https://remoteplease.com">Remote Please</a>
                         <!-- Not removing these links is part of the license conditions of the template. Thanks for understanding :) If you want to use the template without the attribution links, you can do so after supporting further themes development at https://bootstrapious.com/donate  -->
                    </p>

                </div>
            </div>
        </div>
        <!-- /#copyright -->

        <!-- *** COPYRIGHT END *** -->



    </div>
    <!-- /#all -->

    <!-- #### JAVASCRIPT FILES ### -->

    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script>
        window.jQuery || document.write('<script src="<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js"><\/script>')
    </script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.2/js/bootstrap.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/jquery.cookie.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.counterup.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.parallax-1.1.3.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/front.js"></script>

    

    <!-- owl carousel -->
    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>



</body>

</html>